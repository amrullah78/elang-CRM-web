# Elang CRM Web

Aplikasi CRM kunjungan salesman berbasis web.

## Cara Deploy ke Vercel

1. Upload folder `client/` ini ke GitHub (bisa rename sesuai nama repo Anda).
2. Deploy ke Vercel:
   - Pilih framework: **Vite**
   - Root directory: `client`
   - Output directory: `dist`
3. Jalankan dan akses URL dari Vercel.

📁 Struktur sudah siap untuk Vercel deployment.
