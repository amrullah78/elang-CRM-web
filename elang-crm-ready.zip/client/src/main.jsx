import React from 'react';
import ReactDOM from 'react-dom/client';

const App = () => <h1>Welcome to Elang CRM</h1>;

ReactDOM.createRoot(document.getElementById('root')).render(<App />);