# Elang CRM Web

Aplikasi CRM kunjungan salesman berbasis web.

## Cara Deploy ke Vercel

1. Upload folder `client` ini ke GitHub
2. Di [vercel.com](https://vercel.com):
   - Import dari GitHub
   - Framework: Vite
   - Root Directory: `client`
   - Deploy

CRM akan langsung online!
