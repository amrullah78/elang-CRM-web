-- SQL schema for Sales CRM (Postgres - Supabase)
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role text not null default 'salesman',
  area text,
  created_at timestamptz default now()
);

create table outlets (
  id bigserial primary key,
  code text unique,
  name text not null,
  address text,
  area text,
  type text,
  contact_name text,
  contact_phone text,
  created_at timestamptz default now()
);

create table daily_plans (
  id bigserial primary key,
  planner_id uuid references profiles(id) on delete set null,
  plan_date date not null,
  area text,
  route_order int,
  outlet_id bigint references outlets(id) on delete set null,
  status text default 'planned',
  notes text,
  created_at timestamptz default now()
);

create table visits (
  id bigserial primary key,
  salesman_id uuid references profiles(id),
  outlet_id bigint references outlets(id),
  visit_time timestamptz default now(),
  plan_id bigint references daily_plans(id),
  duration_minutes int,
  visit_result text,
  transaction_amount numeric default 0,
  transaction_count int default 0,
  photo_url text,
  created_at timestamptz default now()
);

create table activity_logs (
  id bigserial primary key,
  user_id uuid references profiles(id),
  action text,
  meta jsonb,
  created_at timestamptz default now()
);

create index on visits (visit_time);
create index on daily_plans (plan_date, area);
create index on outlets (area);
