# Sales CRM - Starter (Supabase + React (Vite) + Tailwind)
This is a minimal starter project for a Salesman Monitoring web app (PWA) using Supabase for auth, realtime DB, and storage.

## What's included
- React + Vite scaffold (minimal)
- Tailwind setup files
- Supabase client helper
- Example pages: Auth, Dashboard (admin & salesman), Plans, Visits
- PWA manifest + simple service worker
- SQL schema for Supabase (`sql/schema.sql`)
- `.env.example` showing required env vars
- `README` with quick deploy steps to Supabase + Vercel

## How to use locally
1. Install Node (v18+ recommended) and pnpm/yarn/npm.
2. Copy `.env.example` to `.env` and fill your Supabase URL and ANON KEY.
3. Install deps: `npm install`
4. Run dev server: `npm run dev`
5. Build: `npm run build`

## Deploy
- Create a Supabase project, run the SQL in `sql/schema.sql` in Supabase SQL Editor.
- Create a GitHub repo and push this project.
- Connect the repo to Vercel and set environment variables from `.env.example`.
- Deploy — the site will be available as a PWA for Android (Add to Home Screen).

## Notes
- This is an MVP starter. Add RLS (Row Level Security) policies in Supabase before production.
- For file uploads (visit photos), enable Supabase Storage and adapt the `logVisit` flow.

