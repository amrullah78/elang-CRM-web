import React from 'react'
export default function Header({title}) {
  return (
    <header className="p-4 bg-slate-50 border-b">
      <h1 className="text-lg font-semibold">{title}</h1>
    </header>
  )
}
