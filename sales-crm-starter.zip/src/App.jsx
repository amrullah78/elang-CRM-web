import React, { useEffect, useState } from 'react'
import AuthPage from './pages/AuthPage'
import DashboardAdmin from './pages/DashboardAdmin'
import DashboardSalesman from './pages/DashboardSalesman'
import { supabase } from './lib/supabaseClient'

export default function App() {
  const [user, setUser] = useState(null)
  const [profile, setProfile] = useState(null)

  useEffect(() => {
    const session = supabase.auth.getSession().then(r => {
      if (r?.data?.session) {
        setUser(r.data.session.user)
      }
    })
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null)
    })
    return () => listener?.subscription?.unsubscribe?.()
  }, [])

  useEffect(() => {
    if (!user) return;
    supabase.from('profiles').select('*').eq('id', user.id).single()
      .then(({ data, error }) => {
        if (!error) setProfile(data)
      })
  }, [user])

  if (!user) return <AuthPage />
  if (profile?.role === 'admin') return <DashboardAdmin user={user} profile={profile} />
  return <DashboardSalesman user={user} profile={profile} />
}
