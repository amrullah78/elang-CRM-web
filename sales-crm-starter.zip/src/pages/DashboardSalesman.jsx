import React from 'react'
import VisitsPage from './VisitsPage'
import PlanPage from './PlanPage'

export default function DashboardSalesman({ user, profile }) {
  return (
    <div className="p-4">
      <h1 className="text-xl">Salesman Dashboard</h1>
      <p>Welcome, {profile?.full_name}</p>
      <div className="mt-4">
        <PlanPage user={user} profile={profile} />
        <VisitsPage user={user} profile={profile} />
      </div>
    </div>
  )
}
