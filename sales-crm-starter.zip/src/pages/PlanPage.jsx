import React, { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function PlanPage({ user, profile }) {
  const [plans, setPlans] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!profile) return
    setLoading(true)
    supabase.from('daily_plans').select('*').eq('plan_date', new Date().toISOString().slice(0,10)).then(({data})=>{
      setPlans(data||[])
      setLoading(false)
    })
  }, [profile])

  return (
    <div className="mt-4">
      <h3 className="font-semibold">Rencana Hari Ini</h3>
      {loading ? <div>Loading...</div> : (
        <ul>
          {plans.map(p => <li key={p.id} className="py-1 border-b">{p.outlet_id} - {p.status}</li>)}
        </ul>
      )}
    </div>
  )
}
