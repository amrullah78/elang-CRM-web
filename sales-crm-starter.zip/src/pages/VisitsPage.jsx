import React, { useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function VisitsPage({ user }) {
  const [outlet, setOutlet] = useState('')
  const [result, setResult] = useState('')
  const [amount, setAmount] = useState('0')
  const [message, setMessage] = useState('')

  async function submit(e) {
    e.preventDefault()
    const { data, error } = await supabase.from('visits').insert([{
      salesman_id: user.id,
      outlet_id: outlet || null,
      visit_result: result,
      transaction_amount: amount || 0
    }])
    if (error) setMessage(error.message)
    else setMessage('Visit logged')
    setResult(''); setOutlet(''); setAmount('0')
  }

  return (
    <div className="mt-4">
      <h3 className="font-semibold">Log Kunjungan</h3>
      <form onSubmit={submit} className="space-y-2">
        <input placeholder="Outlet ID" value={outlet} onChange={e=>setOutlet(e.target.value)} className="border p-2 w-full" />
        <input placeholder="Hasil kunjungan" value={result} onChange={e=>setResult(e.target.value)} className="border p-2 w-full" />
        <input placeholder="Nominal transaksi" value={amount} onChange={e=>setAmount(e.target.value)} className="border p-2 w-full" />
        <button className="p-2 bg-sky-500 text-white">Submit Visit</button>
        <p className="text-sm">{message}</p>
      </form>
    </div>
  )
}
