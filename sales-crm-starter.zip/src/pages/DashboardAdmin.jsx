import React, { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function DashboardAdmin({ user, profile }) {
  const [visits, setVisits] = useState([])

  useEffect(() => {
    // initial load
    supabase.from('visits').select('*').order('visit_time', {ascending: false}).limit(50).then(({data})=>setVisits(data||[]))
    // realtime subscribe
    const channel = supabase.channel('public:visits')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'visits' }, payload => {
        setVisits(prev => [payload.new, ...prev].slice(0,50))
      })
      .subscribe()
    return () => supabase.removeChannel(channel)
  }, [])

  return (
    <div className="p-4">
      <h1 className="text-xl">Admin Dashboard</h1>
      <p>Welcome, {profile?.full_name}</p>
      <section className="mt-4">
        <h2 className="font-semibold">Recent visits</h2>
        <ul>
          {visits.map(v => (
            <li key={v.id} className="border-b py-2">
              <div>visit id: {v.id} - salesman: {v.salesman_id}</div>
              <div>outlet: {v.outlet_id} - amount: {v.transaction_amount}</div>
              <div>time: {v.visit_time}</div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  )
}
